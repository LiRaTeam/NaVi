//
//  kernSlide.swift
//  Taurine
//
//  Created by CoolStar on 4/3/20.
//  Copyright © 2020 coolstar. All rights reserved.
//

import Foundation

func getKernSlide(our_proc: UInt64) -> UInt64 {
//    let offsets = Offsets.shared
//    
//    let our_ucred = rk64ptr(our_proc + offsets.proc.ucred)
//    let our_entitlements = rk64ptr(rk64ptr(our_ucred + offsets.ucred.cr_label) + 0x8)
//    
//    let vtable = rk64ptr(our_entitlements)
//    
//    let funct = rk64ptr(vtable + (8 * 0x1f)) //osdictionary set object
    
    return get_kslide();
    
//    var kernel_page = funct & ~UInt64(0xfff)
//    while true {
//        let hdr = rk32(kernel_page)
//        if hdr == 0xfeedfacf {
//            print(String(format: "Found kernel base 0x%llx", kernel_page))
//            return kernel_page - UInt64(0xFFFFFFF007004000)
//        }
//        kernel_page -= 0x1000
//    }
}
