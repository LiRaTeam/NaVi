/*
 * Copyright (c) 2023 Félix Poulin-Bélanger. All rights reserved.
 */

#ifndef fileproc_guard_h
#define fileproc_guard_h

struct fileproc_guard {
    u64 fpg_wset;
    u64 fpg_guard;
};

#endif /* fileproc_guard_h */
