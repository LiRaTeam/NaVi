/*
 * Copyright (c) 2023 Félix Poulin-Bélanger. All rights reserved.
 */

#ifndef psemnode_h
#define psemnode_h

struct psemnode {
    u64 pinfo;
    u64 padding;
};

#endif /* psemnode_h */
